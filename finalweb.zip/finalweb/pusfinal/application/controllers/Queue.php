<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Queue extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
        $this->load->model('patient_model');
    }

    public function index() {
        $data['title'] = 'Daftar Antrian';
        $data['queue_list'] = $this->patient_model->get_queue_list(date('Y-m-d'));
        $this->load->view('templates/header', $data);
        $this->load->view('queue/index', $data);
        $this->load->view('templates/footer');
    }

    public function create() {
        $data['title'] = 'Buat Antrian Baru';
        $this->load->view('templates/header', $data);
        $this->load->view('queue/create', $data);
        $this->load->view('templates/footer');
    }

    public function store() {
        $current_number = $this->patient_model->get_current_queue_number(date('Y-m-d'));
        $data = [
            'user_id' => $this->session->userdata('user_id'),
            'nomor_antrian' => $current_number + 1,
            'tanggal' => date('Y-m-d'),
            'status' => 'waiting'
        ];
        
        $this->patient_model->create_queue($data);
        redirect('antrian');
    }
}