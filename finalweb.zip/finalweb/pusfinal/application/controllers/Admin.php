<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->library('session');
        $this->load->database();
        
        // Check admin authentication except for login and auth methods
        if (!in_array($this->router->fetch_method(), ['login', 'auth']) && 
            !$this->session->userdata('admin_logged_in')) {
            redirect('admin/login');
        }
    }

    public function login() {
        if($this->session->userdata('admin_logged_in')) {
            redirect('admin/dashboard');
        }
        $this->load->view('admin/login');
    }

    public function auth() {
        $access_code = $this->input->post('access_code');
        
        $this->db->where('access_code', $access_code);
        $admin = $this->db->get('admin_access')->row();
        
        if($admin) {
            $this->session->set_userdata('admin_logged_in', true);
            redirect('admin/dashboard');
        } else {
            $this->session->set_flashdata('login_failed', 'Kode akses tidak valid');
            redirect('admin/login');
        }
    }

    public function dashboard() {
        $this->load->model('pendaftaran_model');
        $this->load->model('patient_model');
        
        $data['total_patients'] = $this->patient_model->count_all_patients();
        $data['today_queue'] = $this->pendaftaran_model->get_today_count();
        $data['active_queue'] = $this->pendaftaran_model->get_active_queue_count();
        $data['completed_queue'] = $this->pendaftaran_model->get_completed_queue_count();
        
        $this->load->view('admin/dashboard', $data);
    }

    public function logout() {
        $this->session->unset_userdata('admin_logged_in');
        redirect('admin/login');
    }
}