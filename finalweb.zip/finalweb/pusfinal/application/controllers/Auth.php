<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
        $this->load->model('auth_model');
        $this->load->helper('url');  // Add this line to load URL helper
        $this->load->helper('form'); // Also load form helper since we're using forms
    }

    public function login() {
        if($this->session->userdata('logged_in')) {
            redirect('dashboard');
        }

        $this->form_validation->set_rules('nik', 'NIK', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');

        if($this->form_validation->run() === FALSE) {
            $this->load->view('auth/login');
        } else {
            $nik = $this->input->post('nik');
            $password = $this->input->post('password');

            $user = $this->auth_model->login($nik, $password);

            if($user) {
                $user_data = array(
                    'user_id' => $user->id,
                    'nik' => $user->nik,
                    'nama_lengkap' => $user->nama_lengkap,
                    'alamat' => $user->alamat,
                    'logged_in' => true
                );

                $this->session->set_userdata($user_data);
                redirect('dashboard');
            } else {
                $this->session->set_flashdata('login_failed', 'NIK atau Password salah!');
                redirect('auth/login');
            }
        }
    }

    public function register() {
        $this->form_validation->set_rules('nik', 'NIK', 'required|exact_length[16]|is_unique[users.nik]');
        $this->form_validation->set_rules('nama_lengkap', 'Nama Lengkap', 'required');
        $this->form_validation->set_rules('tanggal_lahir', 'Tanggal Lahir', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[users.email]');
        $this->form_validation->set_rules('alamat', 'Alamat', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
        $this->form_validation->set_rules('konfirmasi_password', 'Konfirmasi Password', 'required|matches[password]');

        if($this->form_validation->run() === FALSE) {
            $this->load->view('auth/register');
        } else {
            $data = array(
                'nik' => $this->input->post('nik'),
                'nama_lengkap' => $this->input->post('nama_lengkap'),
                'tanggal_lahir' => $this->input->post('tanggal_lahir'),
                'email' => $this->input->post('email'),
                'alamat' => $this->input->post('alamat'),
                'password' => password_hash($this->input->post('password'), PASSWORD_DEFAULT),
                'created_at' => date('Y-m-d H:i:s')
            );

            if($this->auth_model->register($data)) {
                $this->session->set_flashdata('register_success', 'Registrasi berhasil! Silakan login.');
                redirect('auth/login');
            } else {
                $this->session->set_flashdata('register_failed', 'Registrasi gagal! Silakan coba lagi.');
                redirect('auth/register');
            }
        }
    }

    public function logout() {
        $this->session->unset_userdata('logged_in');
        $this->session->unset_userdata('user_id');
        $this->session->unset_userdata('username');
        redirect('auth/login');
    }

    public function admin_login() {
        if($this->session->userdata('admin_logged_in')) {
            redirect('admin/dashboard');
        }
    
        $this->form_validation->set_rules('access_code', 'Kode Akses', 'required');

        if($this->form_validation->run() === FALSE) {
            $this->load->view('auth/admin_login');
        } else {
            $access_code = $this->input->post('access_code');
            $admin = $this->auth_model->admin_login($access_code);
    
            if($admin) {
                $admin_data = array(
                    'admin_id' => $admin->id,
                    'admin_name' => $admin->nama,
                    'admin_role' => 'admin',
                    'admin_permissions' => ['manage_queue', 'manage_patients', 'view_reports'],
                    'admin_logged_in' => true
                );
                $this->session->set_userdata($admin_data);
                redirect('admin/dashboard');
            } else {
                $this->session->set_flashdata('login_failed', 'Kode akses tidak valid!');
                redirect('auth/admin_login');
            }
        }
    }

    public function admin_logout() {
        $this->session->unset_userdata('admin_logged_in');
        $this->session->unset_userdata('admin_id');
        $this->session->unset_userdata('admin_name');
        $this->session->unset_userdata('admin_role');
        $this->session->unset_userdata('admin_permissions');
        redirect('auth/admin_login');
    }

    public function reset_password() {
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');

        if($this->form_validation->run() === FALSE) {
            $this->load->view('auth/reset_password');
        } else {
            $email = $this->input->post('email');
            $user = $this->auth_model->get_user_by_email($email);
    
            if($user) {
                // Email exists in database
                $token = bin2hex(random_bytes(32));
                $this->auth_model->save_reset_token($user->id, $token);
                $this->session->set_flashdata('reset_success', 'Link reset telah dikirim ke email ' . $email);
            } else {
                // Email not found in database
                $this->session->set_flashdata('reset_failed', 'Email ' . $email . ' tidak terdaftar dalam sistem.');
            }
            redirect('auth/reset_password');
        }
    }
}