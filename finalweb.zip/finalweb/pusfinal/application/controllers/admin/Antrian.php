<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Antrian extends Admin_Controller {
    
    public function __construct() {
        parent::__construct();
        $this->load->model('antrian_model');
    }

    public function index() {
        $data['title'] = 'Kelola Antrian';
        $data['queues'] = $this->antrian_model->get_todays_queues();
        $this->load->view('admin/antrian/index', $data);
    }

    public function update_status($id) {
        $status = $this->input->post('status');
        $result = $this->antrian_model->update_status($id, $status);
        echo json_encode(['success' => $result]);
    }

    public function delete($id) {
        $result = $this->antrian_model->delete($id);
        $this->session->set_flashdata('message', 
            $result ? 'Antrian berhasil dihapus' : 'Gagal menghapus antrian');
        redirect('admin/antrian');
    }
}