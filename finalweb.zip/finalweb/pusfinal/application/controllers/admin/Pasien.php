<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pasien extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
        $this->load->model('patient_model');
        // Check admin authentication
        if (!$this->session->userdata('logged_in') || $this->session->userdata('role') !== 'admin') {
            redirect('auth/admin');
        }
    }

    public function index() {
        $data['title'] = 'Kelola Data Pasien';
        $data['patients'] = $this->patient_model->get_all_patients();
        $this->load->view('admin/pasien/index', $data);
    }
}