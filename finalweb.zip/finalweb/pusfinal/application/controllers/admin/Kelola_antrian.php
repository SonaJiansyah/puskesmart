<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kelola_antrian extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
        $this->load->model('queue_model');
        $this->load->helper(['url', 'form']);
        $this->load->library(['session', 'form_validation']);
        
        if (!$this->session->userdata('admin_logged_in')) {
            redirect('auth/admin_login');
        }
    }

    public function index() {
        $data['title'] = 'Kelola Antrian';
        $data['queues'] = $this->queue_model->get_todays_queues();
        $this->load->view('admin/kelola_antrian/index', $data);
    }

    public function update_status() {
        $queue_id = $this->input->post('queue_id');
        $status = $this->input->post('status');
        
        $result = $this->queue_model->update_status($queue_id, $status);
        echo json_encode(['success' => $result]);
    }

    public function delete($id) {
        $result = $this->queue_model->delete($id);
        $this->session->set_flashdata('message', 
            $result ? 'Antrian berhasil dihapus' : 'Gagal menghapus antrian');
        redirect('admin/kelola-antrian');
    }
}