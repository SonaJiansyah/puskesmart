<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Antrian extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
        $this->load->model('patient_model');
        // Add authentication check
        if (!$this->session->userdata('logged_in')) {
            redirect('auth/login');
        }
    }

    public function index() {
        $data['title'] = 'Kelola Antrian';
        $data['queue_list'] = $this->patient_model->get_queue_list(date('Y-m-d'));
        
        $this->load->view('templates/header', $data);
        $this->load->view('queue/index', $data);
        $this->load->view('templates/footer');
    }

    public function create() {
        $data['title'] = 'Ambil Antrian Baru';
        
        $this->load->view('templates/header', $data);
        $this->load->view('queue/create', $data);
        $this->load->view('templates/footer');
    }

    public function store() {
        $current_number = $this->patient_model->get_current_queue_number(date('Y-m-d'));
        $data = [
            'user_id' => $this->session->userdata('user_id'),
            'nomor_antrian' => $current_number + 1,
            'tanggal' => date('Y-m-d'),
            'status' => 'waiting'
        ];
        
        if ($this->patient_model->create_queue($data)) {
            $this->session->set_flashdata('success', 'Nomor antrian berhasil diambil');
        } else {
            $this->session->set_flashdata('error', 'Gagal mengambil nomor antrian');
        }
        
        redirect('dashboard/antrian');
    }

    public function history() {
        $data['title'] = 'Riwayat Antrian';
        $user_id = $this->session->userdata('user_id');
        $data['queue_history'] = $this->patient_model->get_queue_list_by_user($user_id);
        
        $this->load->view('templates/header', $data);
        $this->load->view('queue/history', $data);
        $this->load->view('templates/footer');
    }
}