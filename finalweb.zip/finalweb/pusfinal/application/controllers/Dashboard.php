<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
        if(!$this->session->userdata('logged_in')) {
            redirect('auth/login');
        }
        $this->load->helper('url');  // Add this line
        $this->load->model('patient_model');
    }

    public function index() {
        $user_id = $this->session->userdata('user_id');
        $this->load->model('pendaftaran_model');
        
        $queue_status = $this->pendaftaran_model->get_queue_status();
        $data['queue_info'] = $queue_status;
        $data['my_queue'] = $this->pendaftaran_model->get_active_queue($user_id);
        $data['title'] = 'Dashboard Pasien';
        $data['user'] = $this->session->userdata();
        $data['patient'] = $this->patient_model->get_patient_data($user_id);
        
        $this->load->view('dashboard/index', $data);
    }

    public function kartu_pasien() {
        $user_id = $this->session->userdata('user_id');
        $patient_data = $this->patient_model->get_patient_data($user_id);
        
        $data['patient'] = (object) array(
            'nama_lengkap' => $patient_data->nama_lengkap,
            'nik' => $patient_data->nik,
            'alamat' => $patient_data->alamat,
            'no_rekam_medis' => 'RM-' . str_pad($user_id, 6, '0', STR_PAD_LEFT)
        );
        
        $data['title'] = 'Kartu Pasien';
        $this->load->view('dashboard/kartu_pasien', $data);
    }

    public function antrian() {
        $user_id = $this->session->userdata('user_id');
        $this->load->model('pendaftaran_model');
        $data['antrian'] = $this->pendaftaran_model->get_active_queue($user_id);
        $this->load->view('dashboard/antrian', $data);
    }

    public function pendaftaran() {
        $this->load->model('layanan_model');
        $data['layanan'] = $this->layanan_model->get_all_layanan();
        $this->load->view('dashboard/pendaftaran', $data);
    }

    public function submit_pendaftaran() {
        $user_id = $this->session->userdata('user_id');
        $tanggal = $this->input->post('tanggal_kunjungan');
        $hari = date('l', strtotime($tanggal));
        $hari_indonesia = array(
            'Sunday' => 'Minggu', 'Monday' => 'Senin', 'Tuesday' => 'Selasa',
            'Wednesday' => 'Rabu', 'Thursday' => 'Kamis', 'Friday' => 'Jumat',
            'Saturday' => 'Sabtu'
        );

        $this->load->model('pendaftaran_model');
        $nomor_antrian = $this->pendaftaran_model->generate_queue_number($tanggal);
        $estimasi = $this->pendaftaran_model->calculate_estimation($tanggal);

        $data = array(
            'user_id' => $user_id,
            'jenis_pembiayaan' => $this->input->post('jenis_pembiayaan'),
            'jenis_layanan' => $this->input->post('jenis_layanan'),
            'tanggal_kunjungan' => $tanggal,
            'hari_kunjungan' => $hari_indonesia[$hari],
            'nomor_antrian' => $nomor_antrian,
            'estimasi_waktu' => $estimasi,
            'sisa_antrian' => $this->pendaftaran_model->count_queue_ahead($tanggal)
        );

        if($this->pendaftaran_model->create($data)) {
            redirect('dashboard/antrian');
        } else {
            $this->session->set_flashdata('error', 'Pendaftaran gagal');
            redirect('dashboard/pendaftaran');
        }
    }

    public function rekam_medis() {
        $user_id = $this->session->userdata('user_id');
        $data['rekam_medis'] = $this->patient_model->get_medical_records($user_id);
        $data['title'] = 'Rekam Medis';
        $this->load->view('dashboard/rekam_medis', $data);
    }

    public function resep_dokter() {
        $user_id = $this->session->userdata('user_id');
        $data['resep'] = $this->patient_model->get_prescriptions($user_id);
        $data['title'] = 'Resep Dokter';
        $this->load->view('dashboard/resep_dokter', $data);
    }

    public function jadwal_dokter() {
        $data['jadwal'] = $this->patient_model->get_doctor_schedules();
        $data['title'] = 'Jadwal Dokter';
        $this->load->view('dashboard/jadwal_dokter', $data);
    }

    public function informasi() {
        $this->load->model('informasi_model');
        $data['informasi'] = $this->informasi_model->get_all_informasi();
        $data['title'] = 'Informasi';
        $this->load->view('dashboard/informasi', $data);
    }
}