<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pasien extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
        $this->load->model('patient_model');
        if (!$this->session->userdata('logged_in')) {
            redirect('auth/login');
        }
    }

    public function index() {
        $data['title'] = 'Data Pasien';
        $data['patients'] = $this->patient_model->get_all_patients();
        
        $this->load->view('templates/header', $data);
        $this->load->view('pasien/index', $data);
        $this->load->view('templates/footer');
    }

    public function detail($id) {
        $data['title'] = 'Detail Pasien';
        $data['patient'] = $this->patient_model->get_patient_data($id);
        
        if (!$data['patient']) {
            show_404();
        }
        
        $this->load->view('templates/header', $data);
        $this->load->view('pasien/detail', $data);
        $this->load->view('templates/footer');
    }

    public function search() {
        $keyword = $this->input->get('keyword');
        $data['patients'] = $this->patient_model->search_patients($keyword);
        $this->load->view('pasien/search_results', $data);
    }
}