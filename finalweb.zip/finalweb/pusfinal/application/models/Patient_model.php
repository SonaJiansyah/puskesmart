<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Patient_model extends CI_Model {
    
    public function get_patient_data($user_id) {
        $this->db->select('users.*, IFNULL(pasien.no_rm, "") as no_rm, IFNULL(pasien.jenis_kelamin, "") as jenis_kelamin, IFNULL(pasien.no_telepon, "") as no_telepon');
        $this->db->from('users');
        $this->db->join('pasien', 'pasien.user_id = users.id', 'left');
        $this->db->where('users.id', $user_id);
        return $this->db->get()->row();
    }

    public function get_all_patients() {
        $this->db->select('users.*, IFNULL(pasien.no_rm, "") as no_rm, IFNULL(pasien.jenis_kelamin, "") as jenis_kelamin, IFNULL(pasien.no_telepon, "") as no_telepon');
        $this->db->from('users');
        $this->db->join('pasien', 'pasien.user_id = users.id', 'left');
        $this->db->where('users.role', 'patient');
        return $this->db->get()->result();
    }

    public function search_patients($keyword) {
        $this->db->select('users.*, pasien.no_rm, pasien.jenis_kelamin, pasien.no_telepon');
        $this->db->from('users');
        $this->db->join('pasien', 'pasien.user_id = users.id', 'left');
        $this->db->where('users.role', 'patient');
        $this->db->group_start();
        $this->db->like('users.nama_lengkap', $keyword);
        $this->db->or_like('users.nik', $keyword);
        $this->db->or_like('pasien.no_rm', $keyword);
        $this->db->group_end();
        return $this->db->get()->result();
    }
    
    public function get_medical_records($user_id) {
        $this->db->where('user_id', $user_id);
        $this->db->order_by('tanggal', 'DESC');
        $query = $this->db->get('rekam_medis');
        return ($query) ? $query->result() : false;
    }

    // Add new method
    public function validate_queue_access($queue_id, $user_id) {
        $this->db->where('id', $queue_id);
        $this->db->where('user_id', $user_id);
        return $this->db->get('antrian')->row();
    }

    public function get_active_queue($user_id) {
        $this->db->where('user_id', $user_id);
        $this->db->where('tanggal', date('Y-m-d'));
        $this->db->where_in('status', ['waiting', 'in_progress']);
        return $this->db->get('antrian')->row();
    }

    public function get_prescriptions($user_id) {
        $this->db->where('user_id', $user_id);
        $this->db->order_by('tanggal', 'DESC');
        return $this->db->get('resep_dokter')->result();
    }

    public function get_doctor_schedules() {
        $this->db->order_by('hari', 'ASC');
        $this->db->order_by('jam_mulai', 'ASC');
        return $this->db->get('jadwal_dokter')->result();
    }

    // Add new queue management methods
    public function create_queue($data) {
        return $this->db->insert('antrian', $data);
    }

    public function get_queue_list($date = null) {
        $this->db->select('antrian.*, users.nama_lengkap, users.nik, pasien.no_rm');
        $this->db->from('antrian');
        $this->db->join('users', 'users.id = antrian.user_id', 'left');
        $this->db->join('pasien', 'pasien.user_id = users.id', 'left');
        if ($date) {
            $this->db->where('antrian.tanggal', $date);
        }
        $this->db->order_by('antrian.tanggal', 'ASC');
        $this->db->order_by('antrian.nomor_antrian', 'ASC');
        return $this->db->get()->result();
    }

    public function get_queue_list_by_user($user_id) {
        $this->db->select('antrian.*, users.nama_lengkap');
        $this->db->from('antrian');
        $this->db->join('users', 'users.id = antrian.user_id', 'left');
        $this->db->where('antrian.user_id', $user_id);
        $this->db->order_by('antrian.tanggal', 'DESC');
        $this->db->order_by('antrian.nomor_antrian', 'ASC');
        return $this->db->get()->result();
    }

    public function check_existing_queue($user_id, $date) {
        $this->db->where('user_id', $user_id);
        $this->db->where('tanggal', $date);
        $this->db->where_in('status', ['waiting', 'in_progress']);
        return $this->db->get('antrian')->num_rows() > 0;
    }

    public function get_current_queue_number($date) {
        $this->db->select_max('nomor_antrian');
        $this->db->where('tanggal', $date);
        $result = $this->db->get('antrian')->row();
        return $result->nomor_antrian ?? 0;
    }

    public function update_queue_status($queue_id, $status) {
        $this->db->where('id', $queue_id);
        return $this->db->update('antrian', ['status' => $status]);
    }

    public function count_all_patients() {
        return $this->db->count_all('users');
    }

    public function check_queue_table() {
        // Check if table exists
        if ($this->db->table_exists('antrian')) {
            // Count records
            $count = $this->db->count_all('antrian');
            return array(
                'exists' => true,
                'count' => $count
            );
        }
        return array(
            'exists' => false,
            'count' => 0
        );
    }

    public function delete_queue($id) {
        $this->db->where('id', $id);
        return $this->db->delete('antrian');
    }
}