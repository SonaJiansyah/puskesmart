<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Antrian_model extends CI_Model {
    
    public function get_todays_queues() {
        $this->db->where('DATE(created_at)', date('Y-m-d'));
        $this->db->order_by('nomor_antrian', 'ASC');
        return $this->db->get('antrian')->result();
    }
    
    public function update_status($id, $status) {
        return $this->db->where('id', $id)
                        ->update('antrian', ['status' => $status]);
    }
    
    public function delete($id) {
        return $this->db->where('id', $id)->delete('antrian');
    }
}