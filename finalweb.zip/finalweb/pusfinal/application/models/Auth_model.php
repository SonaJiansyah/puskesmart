<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth_model extends CI_Model {
    
    public function login($nik, $password) {
        $this->db->where('nik', $nik);
        $user = $this->db->get('users')->row();
        
        if($user && password_verify($password, $user->password)) {
            return $user;
        }
        return false;
    }

    public function register($data) {
        return $this->db->insert('users', $data);
    }

    public function admin_login($access_code) {
        $admin = $this->db->get_where('admin_access', ['is_active' => 1])->row();
        
        if($admin && password_verify($access_code, $admin->access_code)) {
            return true;
        }
        return false;
    }

    public function get_user_by_email($email) {
        return $this->db->get_where('users', ['email' => $email])->row();
    }

    public function save_reset_token($user_id, $token) {
        $this->db->where('id', $user_id);
        return $this->db->update('users', [
            'reset_token' => $token,
            'reset_token_expires' => date('Y-m-d H:i:s', strtotime('+1 hour'))
        ]);
    }
}