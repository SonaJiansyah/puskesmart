<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pendaftaran_model extends CI_Model {
    public function create($data) {
        return $this->db->insert('pendaftaran', $data);
    }

    public function get_today_count() {
        $this->db->where('DATE(created_at)', date('Y-m-d'));
        return $this->db->count_all_results('pendaftaran');
    }

    public function generate_queue_number($tanggal) {
        $this->db->where('DATE(tanggal_kunjungan)', $tanggal);
        $this->db->order_by('id', 'DESC');
        $last_queue = $this->db->get('pendaftaran')->row();
        
        if ($last_queue) {
            $last_number = intval(substr($last_queue->nomor_antrian, 1));
            $new_number = $last_number + 1;
        } else {
            $new_number = 1;
        }
        
        return 'A' . sprintf('%03d', $new_number);
    }

    public function calculate_estimation($tanggal) {
        $this->db->where('DATE(tanggal_kunjungan)', $tanggal);
        $queue_count = $this->db->count_all_results('pendaftaran');
        
        $start_time = strtotime('08:00:00');
        $estimated_time = $start_time + ($queue_count * 15 * 60);
        
        return date('H:i:s', $estimated_time);
    }

    public function count_queue_ahead($tanggal) {
        $this->db->where('DATE(tanggal_kunjungan)', $tanggal);
        $this->db->where('status', 'menunggu');
        return $this->db->count_all_results('pendaftaran');
    }

    public function get_active_queue($user_id) {
        $this->db->where('user_id', $user_id);
        $this->db->where('DATE(tanggal_kunjungan)', date('Y-m-d'));
        $this->db->where('status', 'menunggu');
        $queue = $this->db->get('pendaftaran')->row();
        
        if ($queue) {
            // Get current serving number
            $this->db->select('nomor_antrian');
            $this->db->where('DATE(tanggal_kunjungan)', date('Y-m-d'));
            $this->db->where('status', 'menunggu');
            $this->db->order_by('id', 'ASC');
            $this->db->limit(1);
            $current = $this->db->get('pendaftaran')->row();
            
            $queue->current_number = $current ? $current->nomor_antrian : '0';
        }
        
        return $queue;
    }

    public function get_estimated_time($tanggal) {
        $this->db->where('tanggal_kunjungan', $tanggal);
        $this->db->where('status', 'menunggu');
        $queue_count = $this->db->count_all_results('pendaftaran');
        
        // Start time 08:00
        $start_time = strtotime('08:00:00');
        // Each patient takes 15 minutes
        $estimated_time = $start_time + ($queue_count * 15 * 60);
        
        return date('H:i', $estimated_time);
    }

    public function get_queue_info($user_id) {
        $this->db->where('user_id', $user_id);
        $this->db->where('DATE(tanggal_kunjungan)', date('Y-m-d'));
        $this->db->where('status', 'menunggu');
        $queue = $this->db->get('pendaftaran')->row();
        
        if ($queue) {
            // Count patients ahead in queue
            $this->db->where('tanggal_kunjungan', $queue->tanggal_kunjungan);
            $this->db->where('status', 'menunggu');
            $this->db->where('id <', $queue->id);
            $patients_ahead = $this->db->count_all_results('pendaftaran');
            
            // Calculate estimated time
            $start_time = strtotime('08:00:00');
            $estimated_time = $start_time + ($patients_ahead * 15 * 60);
            
            $queue->estimasi_waktu = date('H:i', $estimated_time);
            $queue->sisa_antrian = $patients_ahead;
        }
        
        return $queue;
    }

    public function get_today_queue_info() {
        $today = date('Y-m-d');
        $this->db->where('DATE(tanggal_kunjungan)', $today);
        $this->db->where('status', 'menunggu');
        $total_waiting = $this->db->count_all_results('pendaftaran');
        
        return [
            'total_antrian' => $total_waiting,
            'current_number' => $this->get_current_queue_number()
        ];
    }

    public function get_my_active_queue($user_id) {
        $today = date('Y-m-d');
        $this->db->where('user_id', $user_id);
        $this->db->where('DATE(tanggal_kunjungan)', $today);
        $this->db->where('status', 'menunggu');
        return $this->db->get('pendaftaran')->row();
    }

    private function get_current_queue_number() {
        $today = date('Y-m-d');
        $this->db->where('DATE(tanggal_kunjungan)', $today);
        $this->db->where('status', 'selesai');
        return $this->db->count_all_results('pendaftaran') + 1;
    }

    public function get_total_today_queue() {
        $today = date('Y-m-d');
        $this->db->where('DATE(tanggal_kunjungan)', $today);
        return $this->db->count_all_results('pendaftaran');
    }

    public function get_queue_status() {
        $today = date('Y-m-d');
        $this->db->where('DATE(tanggal_kunjungan)', $today);
        
        $total = $this->db->count_all_results('pendaftaran');
        $this->db->where('DATE(tanggal_kunjungan)', $today);
        $this->db->where('status', 'selesai');
        $completed = $this->db->count_all_results('pendaftaran');
        $this->db->where('DATE(tanggal_kunjungan)', $today);
        $this->db->where('status', 'menunggu');
        $waiting = $this->db->count_all_results('pendaftaran');
        
        return [
            'total' => $total,
            'completed' => $completed,
            'waiting' => $waiting,
            'current' => $completed + 1
        ];
    }

    public function get_my_todays_queue($user_id) {
        $today = date('Y-m-d');
        $this->db->where('user_id', $user_id);
        $this->db->where('DATE(tanggal_kunjungan)', $today);
        $this->db->where('status', 'menunggu');
        return $this->db->get('pendaftaran')->row();
    }

    public function get_current_serving_number() {
        $today = date('Y-m-d');
        $this->db->select('nomor_antrian');
        $this->db->where('DATE(tanggal_kunjungan)', $today);
        $this->db->where('status', 'menunggu');
        $this->db->order_by('id', 'ASC');
        $this->db->limit(1);
        $result = $this->db->get('pendaftaran')->row();
        
        return $result ? $result->nomor_antrian : '0';
    }

    public function get_completed_queue_count() {
        $this->db->where('DATE(tanggal_kunjungan)', date('Y-m-d'));
        $this->db->where('status', 'selesai');
        return $this->db->count_all_results('pendaftaran');
    }

    public function get_active_queue_count() {
        $this->db->where('DATE(tanggal_kunjungan)', date('Y-m-d'));
        $this->db->where('status', 'menunggu');
        return $this->db->count_all_results('pendaftaran');
    }
}