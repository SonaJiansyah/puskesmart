<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Informasi_model extends CI_Model {
    
    public function get_all_informasi() {
        return array(
            'umum' => array(
                'jam_operasional' => '08.00 - 16.00',
                'alamat' => 'Jl. Kesehatan No. 10',
                'kontak' => '(021) 123456'
            ),
            'pelayanan' => array(
                'Pendaftaran Online dan Offline',
                'Jadwal Dokter',
                'Layanan Laboratorium'
            ),
            'pasien' => array(
                'Hak dan Kewajiban Pasien',
                'Panduan Penggunaan Aplikasi'
            ),
            'kesehatan' => array(
                'Edukasi Penyakit Menular',
                'Tips Hidup Sehat'
            ),
            'pengaduan' => array(
                'Kritik dan Saran',
                'Pengaduan Layanan'
            )
        );
    }
}