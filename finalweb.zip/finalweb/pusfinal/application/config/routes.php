<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'welcome';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

// Add these admin routes
// Admin antrian routes
$route['admin/antrian'] = 'admin/antrian';
$route['admin/antrian/update_status/(:num)'] = 'admin/antrian/update_status/$1';
$route['admin/antrian/delete/(:num)'] = 'admin/antrian/delete/$1';

// Authentication routes
$route['auth/login'] = 'auth/login';
$route['auth/register'] = 'auth/register';
$route['auth/reset-password'] = 'auth/reset_password';
$route['auth/admin'] = 'auth/admin_login';
$route['auth/logout'] = 'auth/logout';

// Dashboard routes
$route['dashboard'] = 'dashboard/index';
$route['dashboard/(:any)'] = 'dashboard/$1';
$route['antrian/daftar'] = 'antrian/create';
$route['antrian/riwayat'] = 'antrian/history';

// Admin authentication routes
$route['auth/admin_login'] = 'auth/admin_login';
$route['auth/admin_logout'] = 'auth/admin_logout';

// Admin dashboard routes
$route['admin/dashboard'] = 'admin/dashboard';
// Admin routes
$route['admin/antrian'] = 'admin/antrian/index';
$route['admin/antrian/update_status/(:num)'] = 'admin/antrian/update_status/$1';
$route['admin/antrian/delete/(:num)'] = 'admin/antrian/delete/$1';
$route['admin/poli'] = 'admin/poli';
$route['admin/dokter'] = 'admin/dokter';
$route['admin/antrian'] = 'admin/antrian';
$route['admin/pasien'] = 'admin/pasien';
$route['admin/pasien/detail/(:num)'] = 'admin/pasien/detail/$1';
$route['admin/pasien/edit/(:num)'] = 'admin/pasien/edit/$1';
$route['admin/pasien/update/(:num)'] = 'admin/pasien/update/$1';
$route['admin/pasien/delete/(:num)'] = 'admin/pasien/delete/$1';
$route['admin/login'] = 'admin/login';
$route['admin/auth'] = 'admin/auth';
$route['dashboard/kartu_pasien'] = 'dashboard/kartu_pasien';
$route['dashboard/antrian'] = 'dashboard/antrian';
$route['dashboard/pendaftaran'] = 'dashboard/pendaftaran';
$route['dashboard/submit_pendaftaran'] = 'dashboard/submit_pendaftaran';
$route['antrian'] = 'queue/index';
$route['antrian/create'] = 'queue/create';
$route['antrian/store'] = 'queue/store';
$route['pasien'] = 'pasien/index';
$route['pasien/detail/(:num)'] = 'pasien/detail/$1';
$route['pasien/search'] = 'pasien/search';
// Admin queue management routes
$route['admin/queue'] = 'admin/queue/index';
$route['admin/queue/update_status/(:num)'] = 'admin/queue/update_status/$1';
$route['admin/queue/delete/(:num)'] = 'admin/queue/delete/$1';
$route['admin/queue/view/(:num)'] = 'admin/queue/view/$1';
$route['admin/queue/process/(:num)'] = 'admin/queue/process/$1';
$route['admin/queue/complete/(:num)'] = 'admin/queue/complete/$1';
// Admin queue management routes
$route['admin/kelola-antrian'] = 'admin/kelola_antrian/index';
$route['admin/kelola-antrian/update_status'] = 'admin/kelola_antrian/update_status';
$route['admin/kelola-antrian/delete/(:num)'] = 'admin/kelola_antrian/delete/$1';
