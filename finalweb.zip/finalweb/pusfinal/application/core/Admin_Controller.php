<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_Controller extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
        $this->load->helper(['url', 'form']);
        $this->load->library(['session', 'form_validation']);
        
        if (!$this->session->userdata('admin_logged_in')) {
            redirect('auth/admin_login');
        }
    }
    
    protected function check_permission($permission) {
        $permissions = $this->session->userdata('admin_permissions');
        if (!in_array($permission, $permissions)) {
            show_error('Unauthorized access', 403);
        }
    }
}