<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jadwal Dokter - Puskesmas</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body class="bg-light">
    <div class="bg-success text-white py-3 position-relative">
        <a href="<?= base_url('dashboard') ?>" class="text-white position-absolute" style="left: 15px; top: 50%; transform: translateY(-50%);">
            <i class="fas fa-arrow-left"></i>
        </a>
        <h5 class="text-center mb-0">Jadwal Dokter</h5>
    </div>

    <div class="container mt-4">
        <?php if(empty($jadwal)): ?>
            <div class="alert alert-info">
                Belum ada jadwal dokter yang tersedia.
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead class="bg-light">
                        <tr>
                            <th>Nama Dokter</th>
                            <th>Spesialis</th>
                            <th>Hari</th>
                            <th>Jam Praktik</th>
                            <th>Ruangan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($jadwal as $j): ?>
                            <tr>
                                <td><?= $j->nama_dokter ?></td>
                                <td><?= $j->spesialis ?></td>
                                <td><?= $j->hari ?></td>
                                <td><?= date('H:i', strtotime($j->jam_mulai)) ?> - <?= date('H:i', strtotime($j->jam_selesai)) ?></td>
                                <td><?= $j->ruangan ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>