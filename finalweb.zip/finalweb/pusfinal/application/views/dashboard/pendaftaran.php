<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pendaftaran - Puskesmas</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .header {
            background: #009688;
            color: white;
            padding: 15px;
            position: relative;
        }
        .back-button {
            color: white;
            text-decoration: none;
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
        }
        .form-container {
            padding: 20px;
        }
        .form-control {
            border-radius: 10px;
            margin-bottom: 15px;
        }
        .btn-daftar {
            background: #007bff;
            color: white;
            border-radius: 10px;
            padding: 10px 30px;
        }
        .btn-kembali {
            background: white;
            color: #dc3545;
            border: 1px solid #dc3545;
            border-radius: 10px;
            padding: 10px 30px;
        }
    </style>
</head>
<body class="bg-light">
    <div class="header">
        <a href="<?= base_url('dashboard') ?>" class="back-button">
            <i class="fas fa-arrow-left"></i>
        </a>
        <h5 class="text-center mb-0">Pendaftaran</h5>
    </div>

    <div class="form-container">
        <?= form_open('dashboard/submit_pendaftaran') ?>
            <select name="jenis_pembiayaan" class="form-control" required>
                <option value="">Jenis Pembiayaan</option>
                <option value="UMUM">UMUM</option>
                <option value="BPJS">BPJS</option>
            </select>

            <select name="jenis_layanan" class="form-control" required>
                <option value="">Jenis Layanan</option>
                <?php foreach($layanan as $l): ?>
                    <option value="<?= $l->nama_layanan ?>"><?= $l->nama_layanan ?></option>
                <?php endforeach; ?>
            </select>

            <input type="date" name="tanggal_kunjungan" class="form-control" id="tanggal_kunjungan" required>
            <input type="text" class="form-control" id="hari_kunjungan" readonly>
            
            <div class="text-center mt-4">
                <button type="submit" class="btn btn-daftar">Daftar</button>
                <a href="<?= base_url('dashboard') ?>" class="btn btn-kembali">Kembali</a>
            </div>
        <?= form_close() ?>
    </div>

    <script>
        const tanggalInput = document.getElementById('tanggal_kunjungan');
        const hariInput = document.getElementById('hari_kunjungan');
        const hariIndonesia = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
        
        tanggalInput.addEventListener('change', function() {
            const date = new Date(this.value);
            const hari = hariIndonesia[date.getDay()];
            hariInput.value = hari;
        });

        // Set min date to today
        tanggalInput.min = new Date().toISOString().split('T')[0];
    </script>
</body>
</html>