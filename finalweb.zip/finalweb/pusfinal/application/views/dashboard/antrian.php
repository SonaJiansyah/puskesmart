<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nomor Antrian - Puskesmas</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .header {
            background: #009688;
            color: white;
            padding: 15px;
            position: relative;
        }
        .back-button {
            color: white;
            text-decoration: none;
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
        }
        .queue-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            margin: 20px;
            text-align: center;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .queue-number {
            font-size: 32px;
            font-weight: bold;
            color: #007bff;
            margin: 20px 0;
        }
        .queue-info {
            border-top: 1px solid #eee;
            padding-top: 15px;
            margin-top: 15px;
        }
    </style>
</head>
<body class="bg-light">
    <div class="header">
        <a href="<?= base_url('dashboard') ?>" class="back-button">
            <i class="fas fa-arrow-left"></i>
        </a>
        <h5 class="text-center mb-0">Nomor Antrian</h5>
    </div>

    <div class="queue-card">
        <i class="fas fa-ticket-alt fa-3x text-primary"></i>
        <h5 class="mt-3">Nomor Antrian Anda</h5>
        <div class="queue-number"><?= $antrian->nomor_antrian ?? '-' ?></div>
        <div class="queue-info">
            <p class="mb-1">Estimasi Dilayani: <?= $antrian->estimasi_waktu ?? '-' ?></p>
            <p class="mb-1">Sisa Antrian: <?= $antrian->sisa_antrian ?? '0' ?> pasien</p>
            <p class="mb-0">Durasi Pemeriksaan: 15 menit</p>
        </div>
        <p class="mt-3 text-muted">Harap tunggu giliran Anda dipanggil.</p>
    </div>
</body>
</html>