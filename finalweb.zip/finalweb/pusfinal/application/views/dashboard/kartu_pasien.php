<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kartu Pasien - Puskesmas</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .header {
            background: #009688;
            color: white;
            padding: 15px;
            position: relative;
        }
        .back-button {
            color: white;
            text-decoration: none;
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
        }
        .patient-card {
            background: white;
            border-radius: 15px;
            padding: 20px;
            margin: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .patient-info {
            margin: 15px 0;
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }
    </style>
</head>
<body class="bg-light">
    <div class="header">
        <a href="<?= base_url('dashboard') ?>" class="back-button">
            <i class="fas fa-arrow-left"></i>
        </a>
        <h5 class="text-center mb-0">Kartu Pasien</h5>
    </div>

    <div class="patient-card">
        <div class="text-center mb-4">
            <i class="fas fa-user-circle fa-4x text-primary"></i>
        </div>
        
        <div class="patient-info">
            <h6>No. Rekam Medis</h6>
            <p><?= $patient->no_rekam_medis ?? '-' ?></p>
        </div>
        
        <div class="patient-info">
            <h6>NIK</h6>
            <p><?= $patient->nik ?? '-' ?></p>
        </div>
        
        <div class="patient-info">
            <h6>Nama Lengkap</h6>
            <p><?= $patient->nama_lengkap ?? '-' ?></p>
        </div>
        
        <div class="patient-info">
            <h6>Alamat</h6>
            <p><?= $patient->alamat ?? '-' ?></p>
        </div>
    </div>
</body>
</html>