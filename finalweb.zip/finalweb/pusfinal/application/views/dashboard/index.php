<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Pasien - Puskesmas</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .menu-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
            padding: 15px;
        }
        .menu-item {
            background: white;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .menu-item i {
            font-size: 24px;
            color: #007bff;
            margin-bottom: 10px;
        }
        .menu-item p {
            margin: 0;
            color: #333;
            font-size: 14px;
        }
        .status-card {
            background: linear-gradient(135deg, #007bff, #0056b3);
            color: white;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 15px;
        }
    </style>
</head>
<body class="bg-light">
    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h4>Dashboard Pasien</h4>
            <a href="<?= base_url('auth/logout') ?>" class="btn btn-outline-danger btn-sm">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
        
        <div class="row mt-3">
            <div class="col-6">
                <a href="<?= base_url('dashboard/kartu_pasien') ?>" class="text-decoration-none">
                    <div class="status-card">
                        <h6>Kartu Pasien</h6>
                        <small>Terdaftar</small>
                        <p class="mb-0">Aktif</p>
                    </div>
                </a>
            </div>
            <div class="col-6">
                <div class="status-card">
                    <h6>Nomor Antrian</h6>
                    <small>Hari ini</small>
                    <div class="d-flex justify-content-between align-items-center mt-2">
                        <div>
                            <small>Sedang Dilayani</small>
                            <p class="mb-0"><?= $queue_info['current'] ?></p>
                        </div>
                        <div>
                            <small>Total</small>
                            <p class="mb-0"><?= $queue_info['total'] ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="alert alert-info mt-3">
            <small>Antrian Saat Ini: <?= isset($current_queue) ? $current_queue : '0' ?></small>
        </div>

        <div class="menu-grid">
            <a href="<?= base_url('dashboard/pendaftaran') ?>" class="menu-item text-decoration-none">
                <i class="fas fa-clipboard-list"></i>
                <p>Pendaftaran</p>
            </a>
            <a href="<?= base_url('dashboard/antrian') ?>" class="menu-item text-decoration-none">
                <i class="fas fa-list-ol"></i>
                <p>No Antrian</p>
            </a>
            <a href="<?= base_url('dashboard/rekam_medis') ?>" class="menu-item text-decoration-none">
                <i class="fas fa-file-medical"></i>
                <p>Rekam Medis</p>
            </a>
            <a href="<?= base_url('dashboard/resep_dokter') ?>" class="menu-item text-decoration-none">
                <i class="fas fa-user-md"></i>
                <p>Resep Dokter</p>
            </a>
            <a href="<?= base_url('dashboard/jadwal_dokter') ?>" class="menu-item text-decoration-none">
                <i class="fas fa-calendar-alt"></i>
                <p>Jadwal Dokter</p>
            </a>
            <a href="<?= base_url('dashboard/informasi') ?>" class="menu-item text-decoration-none">
                <i class="fas fa-info-circle"></i>
                <p>Informasi</p>
            </a>
        </div>
    </div>
</body>
</html>