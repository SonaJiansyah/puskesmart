<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Informasi - Puskesmas</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .info-section {
            margin-bottom: 20px;
            padding: 15px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .info-section h5 {
            color: #007bff;
            margin-bottom: 15px;
        }
        .info-section ul {
            list-style: none;
            padding-left: 0;
        }
        .info-section ul li {
            padding: 8px 0;
            border-bottom: 1px solid #eee;
        }
        .info-section ul li:last-child {
            border-bottom: none;
        }
    </style>
</head>
<body class="bg-light">
    <div class="bg-success text-white py-3 position-relative">
        <a href="<?= base_url('dashboard') ?>" class="text-white position-absolute" style="left: 15px; top: 50%; transform: translateY(-50%);">
            <i class="fas fa-arrow-left"></i>
        </a>
        <h5 class="text-center mb-0">Informasi</h5>
    </div>

    <div class="container mt-4">
        <div class="info-section">
            <h5>Informasi Umum</h5>
            <ul>
                <li>Jam Operasional: 08.00 - 16.00</li>
                <li>Alamat: Jl. Kesehatan No. 10</li>
                <li>Kontak: (021) 123456</li>
            </ul>
        </div>

        <div class="info-section">
            <h5>Informasi Pelayanan</h5>
            <ul>
                <li>Pendaftaran Online dan Offline</li>
                <li>Jadwal Dokter</li>
                <li>Layanan Laboratorium</li>
            </ul>
        </div>

        <div class="info-section">
            <h5>Informasi Pasien</h5>
            <ul>
                <li>Hak dan Kewajiban Pasien</li>
                <li>Panduan Penggunaan Aplikasi</li>
            </ul>
        </div>

        <div class="info-section">
            <h5>Informasi Kesehatan</h5>
            <ul>
                <li>Edukasi Penyakit Menular</li>
                <li>Tips Hidup Sehat</li>
            </ul>
        </div>

        <div class="info-section">
            <h5>Informasi Pengaduan</h5>
            <ul>
                <li>Kritik dan Saran</li>
                <li>Pengaduan Layanan</li>
            </ul>
        </div>
    </div>
</body>
</html>