<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Kata Sandi - Sistem Antrian Puskesmas</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #1a237e 0%, #121858 100%);
            color: white;
            min-height: 100vh;
            display: flex;
            align-items: center;
        }
        .card {
            background: white;
            border-radius: 15px;
            padding: 20px;
        }
        .form-control {
            border-radius: 8px;
            padding: 12px;
            border: 1px solid #e0e0e0;
        }
        .btn-reset {
            background-color: #007bff;
            border: none;
            padding: 12px;
            border-radius: 8px;
            font-weight: 500;
            width: 100%;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <h3 class="text-center text-dark mb-4">Reset Kata Sandi</h3>
                    <?php if($this->session->flashdata('reset_success')): ?>
                        <div class="alert alert-success">
                            <?= $this->session->flashdata('reset_success') ?>
                        </div>
                    <?php endif; ?>
                    <?php if($this->session->flashdata('reset_failed')): ?>
                        <div class="alert alert-danger">
                            <?= $this->session->flashdata('reset_failed') ?>
                        </div>
                    <?php endif; ?>
                    <?= form_open('auth/reset_password') ?>
                        <div class="form-group">
                            <label class="text-dark">Masukkan Email Anda</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-primary btn-reset">Kirim Link Reset</button>
                    <?= form_close() ?>
                    <div class="text-center mt-3">
                        <a href="<?= base_url('auth/login') ?>" class="text-primary">Kembali ke Login</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>