<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistem Antrian Puskesmas</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .form-control {
            border-radius: 8px;
            padding: 12px;
            border: 1px solid #e0e0e0;
        }
        .form-control:focus {
            box-shadow: none;
            border-color: #007bff;
        }
        .btn-login {
            background-color: #007bff;
            border: none;
            padding: 12px;
            border-radius: 8px;
            font-weight: 500;
        }
        .input-group-text {
            background: none;
            border: none;
            padding-right: 0;
        }
        .input-group-prepend {
            margin-right: -40px;
            z-index: 9;
        }
        .form-check {
            margin-top: 15px;
        }
        .forgot-password {
            color: #007bff;
            text-decoration: none;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <h2 class="text-center mb-4">Selamat Datang!</h2>
                <?php if($this->session->flashdata('login_failed')): ?>
                    <div class="alert alert-danger">
                        <?= $this->session->flashdata('login_failed') ?>
                    </div>
                <?php endif; ?>
                <?= form_open('auth/login') ?>
                    <div class="form-group">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-user"></i></span>
                            </div>
                            <input type="text" name="nik" class="form-control pl-5" placeholder="NIK" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-lock"></i></span>
                            </div>
                            <input type="password" name="password" class="form-control pl-5" placeholder="Kata Sandi" required>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between align-items-center">
                        <div class="form-check">
                            <input type="checkbox" class="form-check-input" id="ingat_saya" name="remember">
                            <label class="form-check-label" for="ingat_saya">Ingat Saya</label>
                        </div>
                        <a href="<?= base_url('auth/forgot_password') ?>" class="forgot-password">Lupa Kata Sandi?</a>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block btn-login mt-4">Login</button>
                <?= form_close() ?>
                <p class="text-center mt-3">
                    Belum punya akun? <a href="<?= base_url('auth/register') ?>">Sign Up</a>
                </p>
                <div class="text-center mt-3">
                    <a href="<?= base_url('admin/login') ?>" class="text-muted">
                        <i class="fas fa-user-shield"></i> Login Admin
                    </a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>