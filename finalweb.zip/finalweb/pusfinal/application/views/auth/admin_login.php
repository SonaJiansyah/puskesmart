<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Admin - Puskesmas</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            background-color: #f0f2f5;
        }
        .login-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-top: 50px;
        }
        .form-control {
            border-radius: 8px;
            padding: 12px;
            border: 1px solid #e0e0e0;
        }
        .form-control:focus {
            box-shadow: none;
            border-color: #007bff;
        }
        .btn-login {
            background-color: #007bff;
            border: none;
            padding: 12px;
            border-radius: 8px;
            font-weight: 500;
            width: 100%;
            margin-top: 20px;
        }
        .input-group-text {
            background: none;
            border: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-4">
                <div class="login-card">
                    <h4 class="text-center mb-4">Login Admin</h4>
                    <?php if($this->session->flashdata('login_failed')): ?>
                        <div class="alert alert-danger">
                            <?= $this->session->flashdata('login_failed') ?>
                        </div>
                    <?php endif; ?>
                    <?= form_open('auth/admin_login') ?>
                        <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"><i class="fas fa-shield-alt"></i></span>
                                </div>
                                <input type="password" name="access_code" class="form-control" placeholder="Kode Akses Admin" required>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary btn-login">Login</button>
                    <?= form_close() ?>
                </div>
            </div>
        </div>
    </div>
</body>
</html>