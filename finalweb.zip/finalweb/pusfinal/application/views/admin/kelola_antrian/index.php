<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Antrian</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .header {
            background: #2196F3;
            color: white;
            padding: 15px;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }
        .content {
            margin-top: 60px;
            padding: 15px;
        }
        .queue-card {
            background: white;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 15px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body class="bg-light">
    <div class="header">
        <div class="d-flex align-items-center">
            <a href="<?= base_url('admin/dashboard') ?>" class="text-white mr-3">
                <i class="fas fa-arrow-left"></i>
            </a>
            <h5 class="mb-0">Kelola Antrian</h5>
        </div>
    </div>

    <div class="content">
        <?php if (empty($queues)): ?>
            <div class="text-center mt-5">
                <p>Belum ada antrian hari ini</p>
            </div>
        <?php else: ?>
            <?php foreach ($queues as $queue): ?>
                <div class="queue-card">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <h6>No. Antrian: <?= $queue->nomor_antrian ?></h6>
                        <span class="badge badge-<?= $queue->status == 'waiting' ? 'warning' : ($queue->status == 'in_progress' ? 'info' : 'success') ?>">
                            <?= $queue->status == 'waiting' ? 'Menunggu' : ($queue->status == 'in_progress' ? 'Sedang Dilayani' : 'Selesai') ?>
                        </span>
                    </div>
                    <p class="mb-2">Nama: <?= $queue->nama_pasien ?></p>
                    <div class="d-flex justify-content-between align-items-center">
                        <select class="form-control form-control-sm w-75 status-select" data-id="<?= $queue->id ?>">
                            <option value="waiting" <?= $queue->status == 'waiting' ? 'selected' : '' ?>>Menunggu</option>
                            <option value="in_progress" <?= $queue->status == 'in_progress' ? 'selected' : '' ?>>Sedang Dilayani</option>
                            <option value="completed" <?= $queue->status == 'completed' ? 'selected' : '' ?>>Selesai</option>
                        </select>
                        <button class="btn btn-danger btn-sm" onclick="deleteQueue(<?= $queue->id ?>)">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        $('.status-select').change(function() {
            var id = $(this).data('id');
            var status = $(this).val();
            
            $.post('<?= base_url('admin/kelola-antrian/update_status') ?>', {
                queue_id: id,
                status: status
            }, function(response) {
                if (response.success) {
                    location.reload();
                }
            });
        });

        function deleteQueue(id) {
            if (confirm('Apakah Anda yakin ingin menghapus antrian ini?')) {
                window.location.href = '<?= base_url('admin/kelola-antrian/delete/') ?>' + id;
            }
        }
    </script>
</body>
</html>