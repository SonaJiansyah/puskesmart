<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Puskesmas</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .stat-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .menu-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            text-align: center;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            transition: transform 0.2s;
        }
        .menu-card:hover {
            transform: translateY(-5px);
        }
        .menu-card i {
            font-size: 24px;
            color: #007bff;
            margin-bottom: 10px;
        }
    </style>
</head>
<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="#">Admin Dashboard</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a href="<?= base_url('admin/logout') ?>" class="nav-link">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col-md-3">
                <div class="stat-card">
                    <h6 class="text-muted">Total Pasien</h6>
                    <h3><?= $total_patients ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <h6 class="text-muted">Antrian Hari Ini</h6>
                    <h3><?= $today_queue ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <h6 class="text-muted">Sedang Menunggu</h6>
                    <h3><?= $active_queue ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <h6 class="text-muted">Selesai Dilayani</h6>
                    <h3><?= $completed_queue ?></h3>
                </div>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-md-4">
                <a href="<?= base_url('admin/kelola-antrian') ?>" class="text-decoration-none">
                    <div class="menu-card">
                        <i class="fas fa-list-ol"></i>
                        <h5>Kelola Antrian</h5>
                        <p class="text-muted mb-0">Atur dan pantau antrian pasien</p>
                    </div>
                </a>
            </div>
            <div class="col-md-4">
                <a href="<?= base_url('admin/pasien') ?>" class="text-decoration-none">
                    <div class="menu-card">
                        <i class="fas fa-users"></i>
                        <h5>Data Pasien</h5>
                        <p class="text-muted mb-0">Kelola data pasien</p>
                    </div>
                </a>
            </div>
            <div class="col-md-4">
                <a href="<?= base_url('admin/laporan') ?>" class="text-decoration-none">
                    <div class="menu-card">
                        <i class="fas fa-chart-bar"></i>
                        <h5>Laporan</h5>
                        <p class="text-muted mb-0">Lihat statistik dan laporan</p>
                    </div>
                </a>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>