<?php $this->load->view('admin/templates/header'); ?>
<?php $this->load->view('admin/templates/sidebar'); ?>

<!-- Begin Page Content -->
<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800"><?= $title ?></h1>

    <?php if ($this->session->flashdata('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= $this->session->flashdata('success') ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Daftar Pasien</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>NIK</th>
                            <th>Nama Lengkap</th>
                            <th>Alamat</th>
                            <th>No. Telepon</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; foreach ($patients as $patient): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= $patient->nik ?></td>
                            <td><?= $patient->nama_lengkap ?></td>
                            <td><?= $patient->alamat ?></td>
                            <td><?= $patient->no_telepon ?></td>
                            <td>
                                <a href="<?= base_url('admin/pasien/detail/'.$patient->id) ?>" class="btn btn-info btn-sm">Detail</a>
                                <a href="<?= base_url('admin/pasien/edit/'.$patient->id) ?>" class="btn btn-warning btn-sm">Edit</a>
                                <a href="<?= base_url('admin/pasien/delete/'.$patient->id) ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!-- /.container-fluid -->

<?php $this->load->view('admin/templates/footer'); ?>