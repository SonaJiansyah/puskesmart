<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Antrian</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body { 
            background-color: #f8f9fa; 
        }
        .header {
            background: #2196F3;
            color: white;
            padding: 15px;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }
        .content {
            margin-top: 70px;
            padding: 15px;
        }
        .empty-state {
            text-align: center;
            color: #666;
            padding: 30px 15px;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="d-flex align-items-center">
            <a href="<?= base_url('admin/dashboard') ?>" class="text-white mr-3">
                <i class="fas fa-arrow-left"></i>
            </a>
            <h5 class="mb-0">Data Antrian</h5>
        </div>
    </div>

    <div class="content">
        <?php if (empty($queues)): ?>
            <div class="empty-state">
                <p class="mb-0">Belum ada pasien yang mendaftar.</p>
            </div>
        <?php else: ?>
            <?php foreach ($queues as $queue): ?>
            <div class="card mb-3">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <h6 class="mb-0">Nomor Antrian: <?= $queue->nomor_antrian ?></h6>
                        <span class="badge badge-<?= $queue->status == 'waiting' ? 'warning' : ($queue->status == 'in_progress' ? 'info' : 'success') ?>">
                            <?= $queue->status == 'waiting' ? 'Menunggu' : ($queue->status == 'in_progress' ? 'Sedang Dilayani' : 'Selesai') ?>
                        </span>
                    </div>
                    <p class="mb-2"><?= $queue->nama_lengkap ?></p>
                    <div class="d-flex justify-content-between">
                        <select class="form-control form-control-sm w-75 status-select" data-id="<?= $queue->id ?>">
                            <option value="waiting" <?= $queue->status == 'waiting' ? 'selected' : '' ?>>Menunggu</option>
                            <option value="in_progress" <?= $queue->status == 'in_progress' ? 'selected' : '' ?>>Sedang Dilayani</option>
                            <option value="completed" <?= $queue->status == 'completed' ? 'selected' : '' ?>>Selesai</option>
                        </select>
                        <button class="btn btn-danger btn-sm" onclick="deleteQueue(<?= $queue->id ?>)">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        $('.status-select').change(function() {
            var id = $(this).data('id');
            var status = $(this).val();
            
            $.post('<?= base_url('admin/antrian/update_status/') ?>' + id, {
                status: status
            }, function(response) {
                if (response.success) {
                    location.reload();
                }
            });
        });

        function deleteQueue(id) {
            if (confirm('Apakah Anda yakin ingin menghapus antrian ini?')) {
                window.location.href = '<?= base_url('admin/antrian/delete/') ?>' + id;
            }
        }
    </script>
</body>
</html>