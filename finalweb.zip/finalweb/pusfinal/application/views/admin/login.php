<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - Puskesmas</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .login-container {
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .form-control {
            border-radius: 8px;
            padding: 12px;
        }
        .btn-login {
            background-color: #007bff;
            border: none;
            padding: 12px;
            border-radius: 8px;
            width: 100%;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="login-container">
            <h4 class="text-center mb-4">Login Admin</h4>
            <?php if($this->session->flashdata('login_failed')): ?>
                <div class="alert alert-danger">
                    <?= $this->session->flashdata('login_failed') ?>
                </div>
            <?php endif; ?>
            <?= form_open('admin/auth') ?>
                <div class="form-group">
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><i class="fas fa-key"></i></span>
                        </div>
                        <input type="password" name="access_code" class="form-control" placeholder="Kode Akses Admin" required>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary btn-login">Login</button>
                <div class="text-center mt-3">
                    <a href="<?= base_url() ?>" class="text-muted">
                        <i class="fas fa-arrow-left"></i> Kembali
                    </a>
                </div>
            <?= form_close() ?>
        </div>
    </div>
</body>
</html>