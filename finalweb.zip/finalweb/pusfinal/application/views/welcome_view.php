<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="refresh" content="5;url=<?= base_url('auth/login') ?>">
    <title>Selamat Datang - Puskesmas Kertamukti</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #1a237e 0%, #121858 100%);
            color: white;
            min-height: 100vh;
            display: flex;
            align-items: center;
        }
        .logo-container {
            text-align: center;
            margin-bottom: 2rem;
        }
        .logo {
            width: 150px;
            height: 150px;
            margin-bottom: 1rem;
        }
        .welcome-text {
            text-align: center;
        }
        .welcome-text h1 {
            font-size: 1.8rem;
            margin-bottom: 0.5rem;
            font-weight: 600;
        }
        .welcome-text p {
            color: #ffd700;
            font-size: 1rem;
        }
        .logo-img {
            filter: brightness(0) saturate(100%) invert(77%) sepia(59%) saturate(552%) hue-rotate(359deg) brightness(101%) contrast(106%);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 text-center">
                <div class="logo-container">
                    <img src="<?= base_url('assets/images/logo.png') ?>" alt="Puskesmas Logo" class="logo logo-img">
                </div>
                <div class="welcome-text">
                    <h1>Selamat Datang di Puskemas Kertamukti!</h1>
                    <p>Pendaftaran Pasien di Sini</p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>