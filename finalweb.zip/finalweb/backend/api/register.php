<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers, Content-Type, Access-Control-Allow-Methods, Authorization, X-Requested-With');

include_once '../config/database.php';

$database = new Database();
$db = $database->connect();

$data = json_decode(file_get_contents("php://input"));

// Validate required fields
$required_fields = ['nik', 'nama_lengkap', 'tanggal_lahir', 'email', 'alamat', 'password', 'jenis_kelamin', 'no_telepon'];
foreach($required_fields as $field) {
    if(!isset($data->$field)) {
        echo json_encode([
            'success' => false,
            'message' => ucfirst($field) . ' is required'
        ]);
        exit();
    }
}

// Check if email already exists
$check_email = "SELECT id FROM users WHERE email = ?";
$stmt = $db->prepare($check_email);
$stmt->bind_param("s", $data->email);
$stmt->execute();
$result = $stmt->get_result();

if($result->num_rows > 0) {
    echo json_encode([
        'success' => false,
        'message' => 'Email already exists'
    ]);
    exit();
}

// Check if NIK already exists
$check_nik = "SELECT id FROM users WHERE nik = ?";
$stmt = $db->prepare($check_nik);
$stmt->bind_param("s", $data->nik);
$stmt->execute();
$result = $stmt->get_result();

if($result->num_rows > 0) {
    echo json_encode([
        'success' => false,
        'message' => 'NIK already exists'
    ]);
    exit();
}

// Hash password
$hashed_password = password_hash($data->password, PASSWORD_DEFAULT);

$query = "INSERT INTO users (
    nik, nama_lengkap, tanggal_lahir, email, alamat, password, 
    jenis_kelamin, golongan_darah, no_telepon, alergi, 
    penyakit_kronis, riwayat_operasi
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $db->prepare($query);
$stmt->bind_param("ssssssssssss",
    $data->nik,
    $data->nama_lengkap,
    $data->tanggal_lahir,
    $data->email,
    $data->alamat,
    $hashed_password,
    $data->jenis_kelamin,
    $data->golongan_darah,
    $data->no_telepon,
    $data->alergi,
    $data->penyakit_kronis,
    $data->riwayat_operasi
);

if($stmt->execute()) {
    echo json_encode([
        'success' => true,
        'message' => 'User registered successfully'
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Registration failed'
    ]);
}

$stmt->close();
$db->close();